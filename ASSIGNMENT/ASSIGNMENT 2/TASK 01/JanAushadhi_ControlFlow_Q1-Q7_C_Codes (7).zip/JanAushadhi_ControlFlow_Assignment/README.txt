C ASSIGNMENT Q1-Q7 SOURCE FILES
Student: Anusha
Register Number: 1924260264
Suggested repository: CSA02-1924260264-Assignment2

Files:
Q1_Precedence_DiscountBug.c
Q2_ShortCircuit_Railway.c
Q3_Bitwise_DeviceRegister.c
Q4_GradeClassifier.c
Q5_PrimeLoop_Analysis.c
Q6_LoanRepaymentSchedule.c
Q7_Redesign_PrimeOddDivisors.c

Compile each file:
gcc -std=c11 -Wall -Wextra FILE.c -o program
./program

Q6 sample input:
10000 2 2000

Run all programs yourself and capture real terminal screenshots.
Create Q1 through Q7 folders in GitHub, upload the matching .c file,
and commit each task separately. Q7 is the redesign evidence for Q5.
