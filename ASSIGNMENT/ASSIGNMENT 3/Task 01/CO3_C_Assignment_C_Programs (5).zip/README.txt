CO3 C PROGRAMS - Q1 TO Q7

Contents:
Q1_Library_Search.c          Linear and binary search with comparison counts
Q2_Seating_Sorts.c           Bubble, selection and insertion sort with statistics
Q3_Merit_List_Merge.c        Merge two descending merit lists
Q4_District_Rainfall.c       2-D rainfall computations in separate functions
Q5_SMS_String_Processing.c   Word count, palindrome, uppercase and reversal
Q6_Directory_Name_Search.c   Safe name input, insertion sort, binary search, duplicates
Q7_Election_Counting.c       Election vote validation, count array, ranking and tie check

Compile and run (Mac/Linux):
1. Open Terminal and move into the extracted folder:
   cd CO3_C_Assignment
2. Compile one task, for example:
   gcc Q1_Library_Search.c -o q1
3. Run:
   ./q1

Repeat with Q2_Seating_Sorts.c / q2, Q3_Merit_List_Merge.c / q3, etc.
On Windows with GCC, use: gcc Q1_Library_Search.c -o q1.exe
Then run: .\q1.exe

IMPORTANT:
- Q4 uses generated demonstration rainfall values. Replace the sample-data loop with actual rainfall input/data for a real report.
- Q6 uses a maximum name length of 29 characters plus the terminating null character; longer input is safely truncated by fgets.
- Q7 accepts up to 500,000 votes to support the requested performance experiment, even though the main problem statement mentions 5,000.
- Run each program yourself and capture your own terminal screenshots before submission.
